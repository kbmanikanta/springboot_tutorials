package com.project.utility;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;

public class App 
{
    public static void main( String[] args ) throws SAXException, IOException, ParserConfigurationException
    {
   	
    	String inputFileXMLPath = "C:\\Users\\Bala Manikanta K\\Documents\\test.xml";
    	String appendURL = "http://test.com/";
    	String XMLresponse = UtilityXMLMethod(inputFileXMLPath,appendURL);
    	System.out.print(XMLresponse);
    }
    
    public static String UtilityXMLMethod(String inputFileXMLPath,String appendURL) throws SAXException, IOException, ParserConfigurationException
    {
        StringBuilder str = new StringBuilder();
    	DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
    	DocumentBuilder db = dbf.newDocumentBuilder();
    	Document doc = db.parse(new File(inputFileXMLPath));
    	doc.getDocumentElement().normalize();
    	
    	//root element - here it is output
        Element root = doc.getDocumentElement();
		//System.out.println(root.getNodeName());
		str.append("<" + root.getNodeName()  + ">");
		  
		//get child nodes - here child nodes for Output (Element1)
	    NodeList children = root.getChildNodes();
    	for (int i = 0; i < children.getLength(); i++) 
    	{
	    		Node node =  children.item(i);
	    		if (node.getNodeType() == Node.ELEMENT_NODE) 
	    		{
	    			String nodeName = node.getNodeName();
		    		if(nodeName.startsWith("Element"))
		    		{
		    			//System.out.println(nodeName);
		    			str.append("<" + nodeName  + ">");
		    			//get child nodes - here child nodes for Element1 (Name,Grade)
		    			NodeList childNodes =  node.getChildNodes();
		    			for (int j = 0; j < childNodes.getLength(); j++) 
		    	    	{
		    				Node childNode =  childNodes.item(j);
		    				if (childNode.getNodeType() == Node.ELEMENT_NODE) 
		    	    		{
		    	    	    	String childNodeName = childNode.getNodeName();
		            	     	//System.out.println(childNodeName);
		            	     	if(childNodeName.startsWith("Name"))
		    		    		{
					    			str.append("<" + childNodeName  + ">");
		            	     		String childNodeValue = childNode.getTextContent();
		            	    		str.append(childNodeValue);
		            	    		str.append("</" + childNodeName  + ">");
		            	    		
		            	     		//System.out.println(childNodeValue);
		    		    		}
		            	     	if(childNodeName.startsWith("Grade"))
		    		    		{	            	     		
					    			str.append("<" + childNodeName  + ">");
		            	     		String childNodeValue1 = childNode.getTextContent();
		            	    		str.append(appendURL + childNodeValue1);
		            	    		str.append("</" + childNodeName  + ">");
		    		    		}
		    	    		}
		    	    	}
		    			
		    			str.append("</" + nodeName  + ">");
		    		}		
    		}
        } 
		str.append("</" + root.getNodeName()   + ">");
    	
    	 // System.out.println("XML Response : " + str.toString());
    	  
    	return str.toString();
    }
}

